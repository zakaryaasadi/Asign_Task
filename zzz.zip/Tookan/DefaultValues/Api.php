<?php

namespace Tookan\DefaultValues;


class Api{
    const baseUrlTookanApi = "https://api.tookanapp.com/v2/";
    const timeZone = "-240";
    const apiKey = "5b636183f24a0b44541279701610214218e4c6fc2ad57f375b15";
    const user_id = "90162";
    const number_of_tasks_per_day = 30;
}