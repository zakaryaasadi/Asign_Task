<?php

namespace Tookan\DefaultValues;

class JobType{
    const PickUp = 0;
    const Delivery = 1;
    const Appointment  = 2;
    const FOS = 3;
}