<?php

class AgentModel{
    public $fleet_id = 0;
    public $fleet_thumb_image = "";
    public $fleet_name = "";
}