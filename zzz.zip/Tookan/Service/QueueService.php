<?php

namespace Tookan\Service;

use App\Models\Queue;
use Tookan\Dependency\Singleton;
use Tookan\DefaultValues\Api as DefaultValuesApi;

class QueueService{
    private $isProcessing;

    private $geofenceService;
    private $agentService;
    private $taskService;


    public function __construct()
    {
        $this->isProcessing = false;
        $this->geofenceService = Singleton::Create(GeofenceService::class);
        $this->agentService = Singleton::Create(AgentService::class);
        $this->taskService = Singleton::Create(TaskService::class);
    }


    public function isProcessing(){
        return $this->isProcessing;
    }


    public function addToQueue($job){
        
        if(!$this->geofenceService->isExistsGeofenceByJob($job)){
            return;
        }
        $job['geofence_details'] = json_encode($job['geofence_details']);
        Queue::Create($job);

    }


    public function run(){
        $this->isProcessing = true;
        $jobs = Queue::get();
        foreach($jobs as $job){
            $this->processing($job);
            $job->delete();
        }
        $this->isProcessing = false;
    }


    private function processing($job){            
        $agents = $this->agentService->getAgentsbyJob($job);


        $startdate = strtotime(date("Y-m-d H:i:s"));
        $enddate=strtotime("+10 days", $startdate);


        while($startdate < $enddate){

            $agentIds = $this->agentService->getAgentIdsByAgentList($agents);

            $tasksAgentByDay = $this->taskService->getTasksByAgentIds($agentIds, $startdate);

            $bestAgentId = $this->taskService->getFleetIdByMinNumberOfTasks($tasksAgentByDay);

            if(count($tasksAgentByDay[$bestAgentId]) <= DefaultValuesApi::number_of_tasks_per_day){

                $res_edit_date_task = $this->taskService->requestEditDateTask($job['job_id'], $startdate);

                if($res_edit_date_task->getStatusCode() == 200){
                    $this->taskService->requestAssignAgentToTask($bestAgentId, $job['job_id']);
                    break;
                }

            }else{
                $startdate = strtotime("+1 day", $startdate);
            }
        }
    }

}