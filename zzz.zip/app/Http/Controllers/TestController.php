<?php

namespace App\Http\Controllers;

use Tookan\Http\Api;

class TestController extends Controller
{
    var $res;
    public function getAllTask(){
        // $total_page = 1;
        // $res1 = $this->firstFetchData();
        $allData = [];
        
        
        for($i = 8; $i >= 1 ; $i--){

            $this->res = $this->fetchData($i);
            while($this->res->getStatusCode() != 200);
            $arr = Api::getResponseAsArray($this->res)['data'];


            $aa = array_reverse($arr);

            foreach($aa as $item){
                array_push($allData, (object)[
                    "job_id" => $item['job_id'],
                    "customer_name" => $item['job_pickup_name'],
                    "phone" => $this->getCustomerPhone($item['job_pickup_phone'])
                ]);

            } 
            
        }



        return $allData;
    }


    private function getCustomerPhone($phone){
        $res = substr($phone, strpos($phone, "5"));
        return $res;
    }


    private function fetchData($page){
        $requestBody = [
            "api_key" => "5b636183f24a0b44541279701610214218e4c6fc2ad57f375b15",
            "start_date" => "2021-08-17",
            "end_date" => "2021-11-21",
            "is_pagination" => 1,
            "job_type" => [0,1,2,3],
            "team_id" => 1105452,
            "requested_page" => $page,
            "job_status" => 2
        ];

        return Api::request('get_all_tasks', $requestBody);
    }


    private function firstFetchData(){
        return $this->fetchData(1);
    }
}
